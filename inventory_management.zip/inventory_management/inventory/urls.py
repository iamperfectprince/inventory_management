from .views import CreateItemView, RetrieveItemView, UpdateItemView, DeleteItemView
from rest_framework.routers import DefaultRouter
from django.urls import path, include

# Create a router instance
router = DefaultRouter()
# Register the viewset with the router
router.register(r'items', CreateItemView, basename='item')  # This will handle 'list', 'create', etc.

urlpatterns = [
    path('api/items/', CreateItemView.as_view(), name='item-list-create'),
    path('api/items/<int:pk>/', RetrieveItemView.as_view(), name='retrieve-item'),
    path('api/items/<int:pk>/update/', UpdateItemView.as_view(), name='update-item'),
    path('api/items/<int:pk>/delete/', DeleteItemView.as_view(), name='delete-item'),
    path('api/', include(router.urls)),

]

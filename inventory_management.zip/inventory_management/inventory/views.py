from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.core.cache import cache
from .models import Item
from .serializers import ItemSerializer
from rest_framework import viewsets
import logging

# Initialize logger
logger = logging.getLogger(__name__)

# Create Item View
class CreateItemView(viewsets.ModelViewSet):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer

# Retrieve Item View with Redis Caching
class RetrieveItemView(generics.RetrieveAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [IsAuthenticated]

    def retrieve(self, request, *args, **kwargs):
        item_id = kwargs['pk']
        cached_item = cache.get(f'item_{item_id}')

        if cached_item:
            logger.info(f'Retrieved item {item_id} from cache')
            return Response(cached_item)

        item = self.get_object()
        serializer = self.get_serializer(item)
        cache.set(f'item_{item_id}', serializer.data, timeout=60*15)  # Cache for 15 minutes
        logger.info(f'Item {item_id} retrieved from DB and cached')
        
        return Response(serializer.data)

# Update Item View
class UpdateItemView(generics.UpdateAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        item = serializer.save()
        # Update the cache
        cache.set(f'item_{item.id}', serializer.data, timeout=60*15)  # Cache for 15 minutes
        logger.info(f'Item updated and cached: {item.id}')
        return Response(serializer.data)

# Delete Item View
class DeleteItemView(generics.DestroyAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
    permission_classes = [IsAuthenticated]

    def perform_destroy(self, instance):
        # Remove item from cache
        cache.delete(f'item_{instance.id}')
        logger.info(f'Item deleted and removed from cache: {instance.id}')
        instance.delete()

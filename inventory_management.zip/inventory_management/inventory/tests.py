from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from .models import Item

User = get_user_model()

class ItemTests(APITestCase):

    def setUp(self):
        # Create a user
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.client.login(username='testuser', password='testpass')  # Log in the user

    def test_create_item(self):
        url = reverse('item-list-create')  # Ensure this matches your URL patterns
        data = {'name': 'Test Item', 'quantity': 10, 'price': '9.99'}
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_retrieve_item(self):
        item = Item.objects.create(name='Test Item', quantity=10, price='9.99')
        url = reverse('item-detail', kwargs={'pk': item.pk})  # Ensure this matches your URL patterns
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_update_item(self):
        item = Item.objects.create(name='Test Item', quantity=10, price='9.99')
        url = reverse('item-detail', kwargs={'pk': item.pk})  # Ensure this matches your URL patterns
        data = {'name': 'Updated Item', 'quantity': 5, 'price': '7.99'}
        response = self.client.put(url, data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    def test_delete_item(self):
        item = Item.objects.create(name='Test Item', quantity=10, price='9.99')
        url = reverse('item-detail', kwargs={'pk': item.pk})  # Ensure this matches your URL patterns
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
